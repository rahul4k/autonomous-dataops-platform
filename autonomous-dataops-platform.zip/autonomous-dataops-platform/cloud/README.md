Placeholder for cloud/README.md
