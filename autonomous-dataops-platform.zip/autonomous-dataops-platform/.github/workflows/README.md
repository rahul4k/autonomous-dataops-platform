Placeholder for .github/workflows/README.md
