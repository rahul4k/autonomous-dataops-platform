Placeholder for tests/README.md
