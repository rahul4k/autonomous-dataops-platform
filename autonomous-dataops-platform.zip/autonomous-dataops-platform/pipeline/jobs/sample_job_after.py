Placeholder for pipeline/jobs/sample_job_after.py
