Placeholder for agents/notifier/README.md
