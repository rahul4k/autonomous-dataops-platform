Placeholder for docs/architecture.md
