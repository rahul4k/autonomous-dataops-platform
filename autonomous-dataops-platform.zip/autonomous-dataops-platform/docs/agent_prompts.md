Placeholder for docs/agent_prompts.md
